import{a as t}from"../chunks/entry.qt5ADfBU.js";export{t as start};
